var express = require('express');
var session=require('express-session');
var router = express.Router();
var bodyParser=require('body-parser');

/* GET home page. */
router.use(bodyParser.urlencoded({extended:false}));

router.use(session({
  secret: '123123123123',
  resave: false,
  saveUninitialized: true
}));





//summerproject
router.get('/apply', function(req, res ,next) {
  
  res.render('apply', { title: 'project_apply' });
});



router.get('/admin', function(req, res ,next) {
  if(userAuthority==true){
    
    res.render('admin', { title: 'project_admin' });
  }
  else {
    res.send('권한없음');
   
  }
});


router.get('/login', function(req, res ,next) {
  res.render('login', { title: 'project_login' });
});








router.post('/login',function(req,res,next){

  var id=req.body.id;
  var password=req.body.password;
  
  if(id=='user'&& password=='1111'){
    
    userAuthority=false;
    res.redirect('/admin');
    
  }
  else if(id=='admin'&& password=='2222'){

    
    userAuthority=true;
   
    res.render('admin',{title:'project_admin'});

  }
  else {
    res.redirect('/login');
  }

})






module.exports = router;
