var express = require('express');
var session = require('express-session');

var mysql = require('mysql');
var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '971120',
  database: 'test'
});

connection.connect();

var router = express.Router();
var bodyParser = require('body-parser');

router.use(bodyParser.urlencoded({ extended: false }));

router.use(session({
  secret: '123456789!@#$%^&*(',
  resave: false,
  saveUninitialized: true
}));


// var users = [
//   {
//     username: 'suzy',
//     password: 'suzy',
//     displayName: '수지'
//   },
//   {
//     username: 'seona',
//     password: '1120',
//     displayName: '선아'
//   }
// ];

// router.post('/', function(req, res) {
//   var user = {
//     username: req.body.username,
//     password: req.body.password,
//     displayName: req.body.displayName
//   };
//   users.push(user); 
//   // req.session.displayName = req.body.displayName;
//   // req.session.save(function(){
//   //   res.redirect('/login');
//   // })
//   res.redirect('/login');
// });

// router.get('/', function(req, res) {
//   if(req.session.displayName){
//     res.render('instagram_feed', { title:''});
//   }
//   else{
//     res.render('instagram_join', { title:''});
//   }
// });

// router.get('/feed', function(req, res) {
//   if(req.session.displayName){
//     res.render('instagram_feed', { title:''});
//   }
//   else{
//     res.render('instagram_login', { title:''});
//   }
// });

// router.get('/suzy_feed', function(req, res) {
//   if(req.session.displayName){
//     res.render('instagram_suzy_feed', { title:''});
//   }
//   else{
//     res.render('instagram_login', { title:''});
//   }
// });

// router.post('/login', function(req, res) {
//   var uname = req.body.username;
//   var pwd = req.body.password;
//   for(var i=0; i<users.length; i++){
//     var user = users[i];
//     if(uname === user.username && pwd === user.password){
//       req.session.displayName = user.displayName;
//       return req.session.save(function(){
//         res.redirect('/feed');
//       });
//     } 
//   }
//   res.redirect('/login');
// });

// router.get('/login', function(req, res) {
//   if(req.session.displayName){
//     res.render('instagram_feed', { title:''});
//   }
//   else{
//     res.render('instagram_login', { title:''});
//   }
// });

// router.get('/logout', function(req, res) {
//   delete req.session.displayName;
//   res.redirect('/');
// });

var users = [

  ];

router.get('/login', function (req, res) {
  res.render('login', { title: '' });
});

router.post('/login', function (req, res) {
  var id = req.body.userId;
  var pwd = req.body.userPassword;
  var sql = 'SELECT * FROM user';
  connection.query(sql, function (err, rows, fields) {
    if (err) {
      console.log(err);
      res.status(500).send('Internal Server Error');
    }
    else {
      for (var i = 0; i < rows.length; i++) {
        if (id === rows[i].userId && pwd === rows[i].userPassword) {
          req.session.displayName = rows[i].userAuthority;
          return req.session.save(function () {
            res.redirect('/admin');
          });
        }
      }
      res.send('<script type="text/javascript">alert("등록된 ID가 없습니다.");</script>');
    }
  });
});

router.get('/apply', function (req, res) {
  res.render('apply', { title: '' });
});

router.post('/apply', function (req, res) {
  var name = req.body.name;
  var department = req.body.department;
  var stnum = req.body.stnum;
  var phone = req.body.phone;
  var email = req.body.email;
  var sql = 'INSERT INTO apply (name, department, stnum, phone, email) VALUES(?, ?, ?, ?, ?)';
  connection.query(sql, [name, department, stnum, phone, email], function (err, rows, fields) {
    if (err) {
      console.log(err);
      res.status(500).send('Internal Server Error');
    } else {
      res.send('<script type="text/javascript">alert("제출 완료");</script>');
    }
  });
});


router.get('/admin', function (req, res) {
  if (req.session.displayName) {
    // res.render('admin', { title: '' });
    var sql = 'SELECT * FROM apply';
    connection.query(sql, function (err, rows, fields) {
      if (err) {
        console.log(err);
        res.status(500).send('Internal Server Error');
      }
      else {
        for (var i = 0; i < rows.length; i++) {
          var user = rows[i].userId;

          users.push(user); 
          }
      }
    });
    res.send(`
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>관리자</title>
    <style type='text/css'>
        html, body{
            height: 100%;
        }
        body{
            margin: 0;
            font-family: sans-serif;
        }
        .header{
            overflow: hidden;
            height: auto;
            margin: 20px 20px 0 20px;
            font-weight: 600;
        }

        .header span{
            font-size: 11px;
            color: lightgray;
            margin-left: 15px;
        }

        .header .logo{
            text-decoration: none;
            color: gray;
            float: left;
        }

        .header .sign{
            text-decoration: none;
            text-align: center;
            padding: 7px 8px;
            font-size: 10px;
            color: white;
            float: right;
            width: 40px;
            background-color: #81DAF5;
            border-radius: 15px;
        }

        form{
            width: 500px;
            /* text-align: center; */
            margin: 0 auto;
            margin-top: 50px;
            font-family:'굴림';

        }

        .main div.input{
            display: flex;
            width: 100%;
        }
        input[type=text]{
            flex: 1;
            width: 100%;
            border: black solid 1px;
            border-radius: 5px;
            padding: 5px;
            margin: 5px;
        }
        
        input[type=tel], input[type=email]{
            flex: 1;
            width: 100%;
            border: black solid 1px;
            border-radius: 5px;
            padding: 5px;
            margin : 5px;
        }

        label{
            color: lightgray; 
        }

        h3{
            margin-top: 20px;
            margin-bottom: 5px;
            font-weight: 600;
        }

        textarea{
            width: 100%;
            border: black 1px solid;
            width: 100%;
            height: 100px;
            border-radius: 5px;
            margin: 5px;
            width: 485px;
        }

        .nav{
            float:left;
        }

        ul li{
            background-color: #81DAF5;
            border-radius: 5px;
            padding: 5px 15px;
            margin: 10px;
            color: white;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="header">
        <a class="logo" href="">OpenYearRound</a>
        <span>지원서보기</span>
        <a class="sign" href="/admin">admin</a>
    </div>
    <div class="main">
        <div class="nav">
            <ul style="list-style: none">     
              <script>
              for(var i=0; i<users.length; i++)
                // <li>users[i]</li>
              </script>
            </ul>
        </div>
        <form>
            <div class="input">
                <input type="text" placeholder="이름">
                <input type="text" placeholder="학과">
                <input type="text" placeholder="학번">
            </div>
            <div class="input">
            <input type="tel" placeholder="전화번호">
            <input type="email" placeholder="이메일">
            </div>
            <label for="mil"><input type="checkbox" name="mil">군필</label>
            <label for="mil"><input type="checkbox" name="mil">미필</label>
            <h3>지원동기</h3>
            <textarea>
            </textarea>
            <h3>프로젝트 경험</h3>
            <textarea>
            </textarea>
        </form>
    </div>
</body>
</html>
`);
  }
  else {
    res.send('<script type="text/javascript">alert("권한 없음");</script>');
  }
});

module.exports = router;

// connection.end();