var submit = document.getElementById("submit");

submit.onclick = function(){
    $.ajax({
        method : "POST",
        url : "/apply",
        data : {
            name : $('#one').val(),
            major : $('#two').val(),
            classnumber : $('#three').val(),
            phonenumber : $('#four').val(),
            email : $('#five').val(),
            reasonforapply : $('#reason').val(),
            expreience : $('#project').val()
        }
    }).done(function (value) {
        alert("제출 완료");
    });
}