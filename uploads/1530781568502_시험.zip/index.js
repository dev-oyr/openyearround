var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/apply', function(req, res, next) {
  res.render('apply');
});
router.get('/admin', function(req, res, next) {
  if(req.session.isapply){
    res.render('admin');
  }
  else
    res.render('fail');
});
router.get('/login', function(req, res, next) {
  res.render('login');
});
/*router.get('/test', function(req, res, next) {
  res.render('practice');
});*/

router.get('/', function(req, res, next) {
  res.render('instagram_login');
});

router.get('/feed', function(req, res, next) {
  if(req.session.isLogin){
    res.render('instagram_feed');
  }
  else
    res.redirect('/');
});

router.get('/mypage', function(req, res, next) {
  if(req.session.isLogin)
    res.render('instagram_mypage');
  else
    res.redirect('/');
});

/*router.post('/login', function(req,res,next){
    if(req.body.phonenumber == '01089311483' && req.body.name == '신유정' && req.body.nickname == 'yu__jung419' && req.body.password == '1234'){
      req.session.isLogin = true;
      res.send(200);
    }
    else
      res.redirect('/');    
});*/

router.post('/apply', function(req,res,next){
  if(req.body.name == '1234'){
    res.send(200);
} else
    res.redirect('/apply');
})
router.post('/login', function(req,res,next){
  if(req.body.ID == 'user' && req.body.password == '1111'){
    req.session.isapply = true;
    res.send(200);
} else
    res.redirect('/login');
})


module.exports = router;
