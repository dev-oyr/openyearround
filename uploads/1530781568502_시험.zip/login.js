var sign = document.getElementById("sign");

sign.onclick = function(){
    $.ajax({
        method : "POST",
        url : "/login",
        data : {
            ID : $('#id').val(),
            password : $('#pwd').val()
        }
    }).done(function (value) {
        location.href = '/admin';
    });
}

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '111111',
  database : 'openyearround'
});

connection.connect();
var sql = 'SELECT * FROM user';
connection.query(sql, function (error, results, fields) {
  if (error) {
      console.log(err);
  } else{
      console.log(results);
      console.log('fields', fields);
  }
});
connection.end();