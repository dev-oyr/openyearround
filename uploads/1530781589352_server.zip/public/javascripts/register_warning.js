$(document).ready(function () {
    function rPhone(input) { // 전화번호 000-0000-0000형태만 받음
      var value = $(input).val();
      value = value.split('-').join('');
      var regphone = /^[0-9]{2,3}-[0-9]{3,4}-[0-9]{4}$/;
      return regphone.test(value);
    }
    function rEmail(input) { // email만 가능
      var value = $(input).val();
      var regemail = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;
      return regemail.test(value);
    }
    function rName(input) {
      var value = $(input).val();
      var regname = /^[가-힣a-zA-Z]+$/; // 한글과 영문만 가능
      return regname.test(value);
    }
    function rUsername(input) {
      var value = $(input).val();
      var regusername = /^[a-zA-Z]+$/; //영문만 가능
      return regusername.test(value);
    }
    function rPassword(input) {
      var value = $(input).val();
      var regpassword = /(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/;
      return regpassword.test(value);
    }
  
    $("#signUp").click(function () {
      if (!rPhone("#phoneoremail") & !rEmail("#phoneoremail")) {
        $("#phoneoremail").css("border-color", "#ed4956");
        $(".essential").css("display", "block");
      }
      else if(!rPhone("#phoneoremail") && rEmail("#phoneoremail") ||rPhone("#phoneoremail") && !rEmail("#phoneoremail") ){
        $("#phoneoremail").css("border-color", "#efefef");
      }
  
      if (!rName("#name")) {
        $("#name").css("border-color", "#ed4956");
        $(".essential").css("display", "block");
      }
      else {
        $("#name").css("border-color", "#efefef");
      }
  
      if (!rUsername("#username")) {
        $("#username").css("border-color", "#ed4956");
        $(".essential").css("display", "block");
      }
      else {
        $("#username").css("border-color", "#efefef");
      }
  
      if (!rPassword("#password")) {
        $("#password").css("border-color", "#ed4956");
        $(".essential").css("display", "block");
      }
      else {
        $("#password").css("border-color", "#efefef");
      }
    });
  
  });