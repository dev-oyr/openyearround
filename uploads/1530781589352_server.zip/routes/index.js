var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var session = require('express-session'); 
router.use(bodyParser.urlencoded({ extended: false })); 
var app = express();
var MySQLStore = require('express-mysql-session')(session);//session mysql 스토어를 위해 사용
var bkfd2Password = require("pbkdf2-password");//pbkdf2-password 모듈 사용
var hasher = bkfd2Password();
var passport = require('passport');//passport 모듈 사용
var LocalStrategy = require('passport-local').Strategy;//passport 모듈 사용
var FacebookStrategy = require('passport-facebook').Strategy;
var mysql = require('mysql');//MYSQL 사용하기위해 씀
app.use(bodyParser.urlencoded({extended: false}));

var conn = mysql.createConnection({
  host : 'localhost',
  user : 'root',
  password : 'qwer1234',
  database : 'user',
  port : 3000
  }); 
  conn.connect();//database 접속 완료
  

router.use(session({
    key:'sId',
    secret:'1234qwerasf!@#$asd', //랜덤한값
    resave: false, 
    saveUninitialized: true

}));

router.get('/apply', function(req, res) {
  res.render('apply', { title: 'apply' });
 });
 
 router.get('/login', function(req, res) {
  res.render('login', { title: 'login' });
 });

 
router.post('/login',function(req,res){
  var phoemail = req.body.phoneoremail;
  var pwd = req.body.password;
  if(phoemail === user.phoneoremail && pwd === user.password){
      req.session.displayName = user.phoneoremail;
      res.redirect('/Inst_feed');
  }
  else{
      res.send("Try again");
  }
  // res.send(phoemail);
});







router.get('/Inst_login',function(req,res){
    if(req.session.displayName){//로그인성공했을때
      res.redirect('/Inst_feed');
    }else{
        res.render('Instagram_login');
    }
  });

router.get('/',function(req,res){
    res.render('Instagram_register');
  })

router.get('/Inst_profile',function(req,res){
  if(req.session.displayName){//로그인성공했을때
    res.render('Instagram_profile');
  }else{
//로그인 실패했을때
res.redirect('/Inst_login');
  }
})

router.get('/Inst_feed',function(req,res){
  if(req.session.displayName){//로그인성공했을때
    res.render('Instagram_feed');
  }else{
//로그인 실패했을때
    res.redirect('/Inst_login');
  }
})


router.post('/Inst_login',function(req,res){
    var user={
        phoneoremail:'openyearround@naver.com',
        password:'qwerasd1@#'
    };

    var phoemail = req.body.phoneoremail;
    var pwd = req.body.password;
    if(phoemail === user.phoneoremail && pwd === user.password){
        req.session.displayName = user.phoneoremail;
        res.redirect('/Inst_feed');
    }
    else{
        res.send("Try again");
    }
    // res.send(phoemail);
});

router.get('/logout',function(req,res){
    // delete req.session.displayName;
    req.session.destroy();
    res.clearCookie('sid');
    res.redirect('/');
  });

module.exports = router;


/* GET home page. */
// router.get('/', function(req, res) {
//   res.render('Instagram_register', { title: 'register' });
// });
// router.get('/Inst_profile', function(req, res) {
//   res.render('Instagram_profile', { title: 'profile' });
// });
// router.get('/Inst_feed', function(req, res) {
//     console.log(req.session)
//   res.render('Instagram_feed', { title: 'feed' });
// });
// router.get('/Inst_login', function(req, res) {
//   res.render('Instagram_login', { title: 'login' });
// });


// router.use(session({
//     secret:'1234qwerasf!@#$asd', //랜덤한값
//     resave: false, 
//     saveUninitialized: true
// }));