var express = require('express');
var router = express.Router();
var session = require('express-session');
var bodyParser = require('body-parser');
var mysql = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '970301',
  database : 'openyearround'
});
connection.connect();
router.use(bodyParser.urlencoded({ extended: false }));

router.use(session({
  secret: '1234r5SDFDG^&*(',
  resave: false,
  saveUninitialized: true
}));

router.post('/', function(req,res){
  var user_id='bokjiho';
  var user_pw='1111';
  var displayName='Ji Ho';
  var uname=req.body.username;
  var pwd=req.body.password;
  
  if(uname==user_id && pwd==user_pw){
    req.session.displayName=displayName;
    res.redirect('/feed');
  }
  else{
    res.send('누구세요');
  }
});
router.get('/', function(req, res) {
  res.render('main', { title: 'Express' });
});
router.get('/feed', function(req, res) {
  if(req.session.displayName){
    res.render('feed', { title: 'Express' });
  } else {
    res.send('누구세요');
  }
});
router.get('/myfeed', function(req, res) {
  if(req.session.displayName){
    res.render('myfeed', { title: 'Express' });
  } else {
    res.send('누구세요');
  }
});
router.get('/logout', function(req,res){
  delete req.session.displayName;
  res.redirect('/');
});

router.get('/apply', function(req,res){
  res.render('oyr_apply');
});


router.post('/apply', function(req, res){
  var name=req.body.name;
  var major=req.body.major;
  var student_id=req.body.studentid;
  var phone=req.body.phonenumber;
  var email=req.body.email;
  var army=req.body.army;
  var donggi=req.body.why;
  var exp=req.body.experience;
  
  
  var sql='INSERT INTO applyform (name, major, student ID, phone number, email address) VALUES(?, ?, ?, ?, ?)';
  var params = [name, major, student_id, phone, email, army, ];
  connection.query(sql, params, function(err, rows, fields){
    if(err){
      console.log(err);
    } else {
      console.log("form submitted!");
    }
  });
  
  
  res.send(alert('제출 완료'));
});


router.get('/login', function(req,res){
  res.render('oyr_login');
});

router.get('/admin', function(req,res){
  res.render('oyr_admin');
});
connection.end();

module.exports = router;
