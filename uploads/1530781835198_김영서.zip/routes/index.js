var express = require('express');
var session = require('express-session')
var bodyParser = require('body-parser');
var router = express.Router();
var mysql = require('mysql');

var conn = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "jh1502",
    database : 'o2'
});

var sql='SELECT * FROM topic';

router.use(bodyParser.urlencoded({ extended: false }));

router.use(session({
  secret: '123456789!@#$%^&*(',
  resave: false,
  saveUninitialized: true
}));



router.post('/login', function(req, res) {
  var id = req.body.id;
  var pwd = req.body.password;
  conn.connect();
  var sql='SELECT * FROM user';
  conn.query(sql,function(err,rows,fields){
    if(err){
        console.log(err);
    }else{
        for(var i=0;i<2;i++){
          console.log(i+rows[i].userId+rows[i].userPassword+rows[i].userAuthority);
            if(rows[i].userId==id && rows[i].userPassword==pwd && rows[i].userAuthority==1){
              req.session.right=1;
              return req.session.save(function(){
                res.redirect('/admin');
              });
            }
            res.redirect('/login');
        }
    }
 })});

router.get('/apply', function(req, res) {
  res.render('test_apply', { title: '' });
});

router.get('/login', function(req, res) {
  if(req.session.right){
    res.redirect('/admin');
  }
  else{
    res.render('test_login', { title: '' });
  }
});

router.get('/admin', function(req, res) {
if(req.session.right){
  res.render('test_admin', { title: '' });
}
else{
  res.redirect('/login');
}
});

module.exports = router;
