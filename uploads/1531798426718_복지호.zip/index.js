var express = require('express');
var router = express.Router();
var session = require('express-session');
var bodyParser = require('body-parser');
var mysql = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '970301',
  database : 'openyearround'
});
connection.connect();
router.use(bodyParser.urlencoded({ extended: false }));

router.use(session({
  secret: '1234r5SDFDG^&*(',
  resave: false,
  saveUninitialized: true
}));

router.post('/apply', function(req, res){
  var name=req.body.name;
  var major=req.body.major;
  var student_id=req.body.studentid;
  var phone=req.body.phonenumber;
  var email=req.body.email;
  var army=req.body.army;
  var motivation=req.body.why;
  var project=req.body.experience;
  
  var apply_form='INSERT INTO applyform (name, major, studentId, phoneNumber, emailAddress, army, donggi, project) VALUES(?, ?, ?, ?, ?, ?, ?, ?)';
  var params = [name, major, student_id, phone, email, army, motivation, project];
  connection.query(apply_form, params, function(err, rows, fields){
    if(err){
      console.log(err);
    } else {
      console.log("form submitted!");
    }
  });  
  res.send("<script>alert('제출 완료');</script>");
});

router.post('/login', function(req,res){
  var login_id=req.body.username;
  var login_pw=req.body.password;
  var user_form='SELECT * FROM user';
  req.session.authority=0;

  connection.query(user_form, function(err, rows, fields){
    if(err){
      console.log(err);
    } else {
      for(var i=0; i<rows.length;i++){
        if(login_id==rows[i].userId && login_pw==rows[i].userPassword){
          req.session.authority=rows[i].userAuthority;
          break;
        }
      }
      res.redirect('/admin');
    }
  });
});

/* GET home page. */
router.get('/', function(req, res) {
  res.render('login');
});

router.get('/apply', function(req,res){
  res.render('apply');
});

router.get('/login', function(req,res){
  res.render('login');
});

router.get('/admin', function(req,res){
  if(req.session.authority==1){
    var applyInfo="SELECT * FROM applyform";
    connection.query(applyInfo, function(err,rows,fields){
      if(err){
        console.log(err);
      } else {
        res.render('admin',{
          data : rows,
        });
      }
    });
  } else {
    res.send('<script>alert("권한 없음");</script>');
  }
});

//connection.end();
module.exports = router;