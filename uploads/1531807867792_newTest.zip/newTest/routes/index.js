var express = require('express');
var router = express.Router();
var bodyParser=require('body-parser');

var mysql=require('mysql');
var session=require('express-session');

/* GET home page. */


/*
router.use(bodyParser.urlencoded({extended:false}));

router.use(session({
  secret: '123123123123',
  resave: false,
  saveUninitialized: true
}));

*/
//

router.get('/', function(req, res) {
  res.render('index', { title: 'Express' });
});





var conn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "1649",
  database : 'users'
});

conn.connect();
var sql='SELECT * FROM topic'; //topic은 테이블 이름

conn.query(sql,function(err,rows,fields){
  if(err){
    console.log(err);
  }else{ 
    console.log('데이터베이스랑 연결됨!');
  }
});

router.get('/apply', function(req, res ,next) {
  
  res.render('apply', { title: 'project_apply' });
});



router.get('/admin', function(req, res ,next) {
  if(userAuthority==true){
    


    var applyInfo="SELECT * FROM apply";
    conn.query(applyInfo, function(err,rows,fields){
      if(err){
        console.log(err);
      } else {
        // 군필 미필 여부 값 전달
        if(rows[0].mil=='n'){
          var m='n';
        } else {
          var m='y';
        }
        
        var a=function(m){
          alert(m);
          if(m=='y'){ 
            $( '#y' ).prop('checked', true) 
          }
          else{
            $( '#n' ).prop('checked', true) 
          }      
                
        };
        
        res.render('admin',{
          data : rows,
          이름: rows[0].name,
          학과: rows[0].major,
          학번: rows[0].student_id,
          전화번호: rows[0].phone_number,
          이메일: rows[0].email,
          군대: rows[0].military,
          지원동기: rows[0].movitation,
          프로젝트경험: rows[0].experience
        });
       
        
      }
    });
    


    
  }
  else {
    
    res.send("<script>alert('권한없음');</script>");
    res.redirect('/apply');
  }
});


router.get('/login', function(req, res ,next) {
  res.render('login', { title: 'project_login' });
});




router.post('/login',function(req,res,next){

  var id=req.body.id;
  var password=req.body.password;
  conn.query(sql,function(err,rows,fields){
    if(id==rows[0].userId && password==rows[0].userPassword){
      
      userAuthority=false;
      res.redirect('/admin');
      
    }
    else if(id==rows[1].userId&& password==rows[1].userPassword){

      
      userAuthority=true;
    
      res.redirect('/admin');

    }
    else {
      res.redirect('/login');
    }
  })
})


router.post('/apply',function(req,res,next){
  var name=req.body.name;
  var major=req.body.major;
  var student_id=req.body.student_id;
  var phone_number=req.body.phone_number;
  var email=req.body.email;
  var mot=req.body.mot;
  var exp=req.body.exp;
  var mil=req.body.mil;// y or n

 
  var apply_form='INSERT INTO apply (name, major, student_id, phone_number, email, military, motivation, experience) VALUES(?, ?, ?, ?, ?, ?, ?, ?)';
  var params = [name, major, student_id, phone_number, email, mil, mot, exp];

  conn.query(apply_form, params, function(err, rows, fields){
    if(err){
      console.log(err);
    } else {
      console.log("제출 완료");
    }
  });  

  res.send("<script>alert('제출 완료');</script>");


});


module.exports = router;
