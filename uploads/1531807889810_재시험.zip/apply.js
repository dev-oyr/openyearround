$('body').ready(function(){
    $('#submitButton').click(function(){
        var name = $('input[name="name"]').val();
        var major = $('input[name="major"]').val();
        var classnumber = $('input[name="classnumber"]').val();
        var phonenumber = $('input[name="phonenumber"]').val();
        var email = $('input[name="email"]').val();
        var militaryok = $('input[name="militaryok"]').is(":checked");
        var militaryno = $('input[name="militaryno"]').is(":checked");
        var reason = $('input[name="reason"]').val();
        var expreience = $('input[name="expreience"]').val();

        
        $.ajax({
            method: "POST",
            url: "/apply",
            data: { 
                name: name,
                major : major,
                classnumber : classnumber,
                phonenumber : phonenumber,
                email : email,
                militaryok : militaryok,
                militaryno : militaryno,
                reason : reason,
                expreience : expreience
            }
          }).done(function( msg ) {
            alert( "Data Saved: 제출완료 " + msg );
        });
    });
});