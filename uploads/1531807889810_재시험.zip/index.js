var express = require('express');
var router = express.Router();
var mysql = require('mysql');

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '111111',
  database : 'open'
});
connection.connect();

router.get('/login', function(req, res, next) {
  res.render('login', { title: 'Express' });
});

router.post('/login', function(req, res, next) {
  var usersForm='SELECT * FROM users';

  connection.query(userForm, function(err, rows, fields){
    if(err){
      console.log(err);
    } else{
      for(var i=0; i<rows.length;i++){
        if(req.body.id == rows[i].userId && req.body.password == rows[i].userPassword)
          res.send({result : 'admin'});
        else
          res.send({result : 'not'});
      }
    }
  });
});

/*router.post('/login', function(req,res){
  var usersForm='SELECT * FROM users';
  //req.session.authority=0;

  connection.query(userForm, function(err, rows, fields){
    if(err){
      console.log(err);
    } else {
      for(var i=0; i<rows.length;i++){
        if(req.body.id==rows[i].userId && req.body.password==rows[i].userPassword){
          //req.session.authority=rows[i].userAuthority;
          res.render('admin');
          break;
        }
        else res.render('fail');
      }
    }
  });
});*/

/*router.get('/admin', function(req, res, next) {
  if(req.session.isLogin){
    res.render('admin');
  } else
      res.render('fail');
});*/

router.get('/apply', function(req, res, next) {
  res.render('apply', { title: 'Express' });
});

router.post('/apply', function(req, res, next) {

  var body = req.body;
  var myQuery = "insert into openyearround(name,major,classnumber,phonenumber,email,milok,milno,reason,experience) values ('"+body.name+"','"+ body.major +"','"+ body.classnumber +"','"+body.phonenumber+"','"+ body.email+"',"+ body.militaryok +", "+ body.militaryno +",'"+body.reason+"','"+ body.expreience +"')";
  connection.query(myQuery, function (error, results, fields) {
    console.log(results);
    if (error) throw error;
    res.send(200);
  });
}); //데이터 서버로 넘기기

router.get('/admin', function(req, res, next) {
  connection.query('select * from apply', function (error, results, fields) {
    if (error) throw error;
    res.render('admin', { data: results });
  });
});

router.post('/info/:name' , function(req, res, next){
  connection.query("select * from apply where name = '" + req.params.name + "'", function (error, results, fields) {
    if (error) throw error;
    res.send({ data: results });
  });
});

router.get('/fail', function(req, res, next) {
  res.render('fail', { title: 'Express' });
});



module.exports = router;
