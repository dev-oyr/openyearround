var heart = document.getElementsByClassName('heart');
var number = document.getElementsByClassName('number');
var clicked=0;
var goodnum=35;
        function GreatHeart() {
          for(i=0; i<3; i++)
          {
            if(clicked==0){
              heart[i].style.cssText = 'display: block; overflow: hidden; text-indent: 110%; white-space: nowrap; background-size: 460px 417px; background-position: -413px 0; background-image: url(https://www.instagram.com/static/bundles/base/sprite_core_2x.png/f52dcc95cb45.png); height: 24px; width: 24px; background-repeat: no-repeat;';
              number[i].innerHTML=++goodnum; 
                clicked=1;
            }
            else{
              heart[i].style.cssText = 'display: block; overflow: hidden; text-indent: 110%; white-space: nowrap; background-position: -413px -25px; background-size: 460px 417px;background-image: url(https://www.instagram.com/static/bundles/base/sprite_core_2x.png/f52dcc95cb45.png); height: 24px; width: 24px; background-repeat: no-repeat';
              number[i].innerHTML=--goodnum; 
                clicked=0;
            }
          }
        }





var xclick = 0;
var asearched = document.getElementById('asearched');
var jsearched = document.getElementById('jsearched');
var njsearched = document.getElementById('njsearched');
var clicksearch = document.getElementById('clicksearch');
var clickclose = document.getElementById('clickclose');

jsearched.addEventListener('click', research);
asearched.addEventListener('blur', nclicksearch1);
clickclose.addEventListener('click', clicksearch2);

function closex(){
    xclick = 1;
}

function closexx(){
    xclick = 0;
}

function research(){
    jsearched.style.display = 'none';
    clicksearch.style.display = 'block';
    asearched.focus();
  }
  
  function nclicksearch1(){
    if(xclick != 1)
    {
      if (asearched.value == "") {
        njsearched.innerHTML = "검색";
      }
      else {
        njsearched.innerHTML = asearched.value;
      }
      jsearched.style.display = 'block';
      clicksearch.style.display = 'none';
    }
  }
  
  function clicksearch2(){
    njsearched.innerHTML = "검색";
    asearched.value = "";
    jsearched.style.display = 'block';
    clicksearch.style.display = 'none';
  }



  var modal = document.getElementById('modalopen');
  var dot3btn = document.getElementById('dot3btn');
  var cancelation = document.getElementById('cancelation');
  
  dot3btn.addEventListener('click', openbtn);
  cancelation.addEventListener('click', cancelclose);
  window.addEventListener('click', outsideClick);
  
  function openbtn() {
    modal.style.display = 'block';
  }
  
  function cancelclose() {
    modal.style.display = 'none';
  }
  
  function outsideClick(e) {
    if (e.target == modal) {
      modal.style.display = 'none';
    }
  }