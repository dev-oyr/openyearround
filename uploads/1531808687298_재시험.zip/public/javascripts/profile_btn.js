var modal = document.getElementById('openmenubtn');
var optpictbtn = document.getElementById('optpictbtn');
var closexbtn = document.getElementById('closexbtn');
var cancelbtn = document.getElementById('cancelbtn');

optpictbtn.addEventListener('click', openbtn);
closexbtn.addEventListener('click', closedx);
cancelbtn.addEventListener('click', cancelclose);
window.addEventListener('click', outsideClick);

function openbtn() {
  modal.style.display = 'block';
}

function closedx() {
  modal.style.display = 'none';
}

function cancelclose() {
  modal.style.display = 'none';
}

function outsideClick(e) {
  if (e.target == modal) {
    modal.style.display = 'none';
  }
}
//옵션


//게시물사진
var backm = document.getElementById('openpicturebtn');
var pictureopen = document.getElementById('pictureopen');
var pictclbtn = document.getElementById('pictclbtn');

pictureopen.addEventListener('click', popenbtn);
pictclbtn.addEventListener('click', closexxx);
window.addEventListener('click', outsideClick);

function popenbtn() {
  backm.style.display = 'block';
}

function closexxx() {
  backm.style.display = 'none';
}

function outsideClick(e) {
  if (e.target == backm) {
    backm.style.display = 'none';
  }
}


//프로필사진
var cover = document.getElementById('popenmenubtn2');
var btnprofile = document.getElementById('btnprofile');
var pclosexbtn2 = document.getElementById('pclosexbtn2');
var pcancelbtn2 = document.getElementById('pcancelbtn2');

btnprofile.addEventListener('click', opening);
pclosexbtn2.addEventListener('click', cloxx);
pcancelbtn2.addEventListener('click', cancexx);
window.addEventListener('click', outsidec);

function opening() {
  cover.style.display = 'block';
}

function cloxx() {
  cover.style.display = 'none';
}

function cancexx() {
  cover.style.display = 'none';
}

function outsidec(e) {
  if (e.target == cover) {
    cover.style.display = 'none';
  }
}

//검색창
var xclick = 0;
var asearched = document.getElementById('asearched');
var jsearched = document.getElementById('jsearched');
var njsearched = document.getElementById('njsearched');
var clicksearch = document.getElementById('clicksearch');
var clickclose = document.getElementById('clickclose');

jsearched.addEventListener('click', research);
asearched.addEventListener('blur', nclicksearch1);
clickclose.addEventListener('click', clicksearch2);



function closex(){
    xclick = 1;
}

function closexx(){
    xclick = 0;
}

function research(){
    jsearched.style.display = 'none';
    clicksearch.style.display = 'block';
    asearched.focus();
  }
  
  function nclicksearch1(){
    if(xclick != 1)
    {
      if (asearched.value == "") {
        njsearched.innerHTML = "검색";
      }
      else {
        njsearched.innerHTML = asearched.value;
      }
      jsearched.style.display = 'block';
      clicksearch.style.display = 'none';
    }
  }
  
  function clicksearch2(){
    njsearched.innerHTML = "검색";
    asearched.value = "";
    jsearched.style.display = 'block';
    clicksearch.style.display = 'none';
  }


//마우스 움직일때
function mouseOver(){
  document.getElementById('mousemove').style.display = 'block';
}
function mouseOut(){
  document.getElementById('mousemove').style.display = 'none';
}

