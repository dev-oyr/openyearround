var express = require('express');
var session = require('express-session');
var mysql = require('mysql');
var conn = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'wldms1404',
  database: 'user'
});

conn.connect();//database 접속 완료
// var sql = 'SELECT * FROM information';
// conn.query(sql, function (err, results, fields) {
//   if (err) {
//     console.log(err);
//   } else {
//     console.log(results);
//     console.log('fields', fields);
//   }
// });
// conn.end;
var router = express.Router();
var bodyParser = require('body-parser');
router.use(bodyParser.urlencoded({ extended: false }));

router.use(session({
  // key: 'sId',
  secret: '1234qwerasf!@#$asd', //랜덤한값
  resave: false,
  saveUninitialized: true

}));

router.get('/login', function (req, res) {
  res.render('login', { title: 'login' });
});

router.post('/login', function (req, res) {
  var Userid = req.body.Userid;
  var UPassword = req.body.UPassword;
  var sql = 'SELECT * FROM information';
  conn.query(sql, function (err, rows, fields) {
    if (err) {
      console.log(err);
      res.status(500).send('error!!');
    }
    else {
      for (var i = 0; i < rows.length; i++) {
        if (Userid == rows[i].userId && UPassword == rows[i].userPassword) {
          req.session.displayName = rows[i].userAuthority;
          console.log(req.session.displayName);
          return req.session.save(function () {
            res.redirect('/admin');
          });
        }
      }
      res.send('<script type = "text/javascript">alert("올바른 정보가 아닙니다.");</script>');
    }
  });
});

router.get('/apply', function (req, res) {
  res.render('apply', { title: 'apply' });
});

router.post('/apply', function (req, res) {
  var Uname = req.body.Uname;
  var Uclass = req.body.Uclass;
  var Unumber = req.body.Unumber;
  var Uphone = req.body.Uphone;
  var Uemail = req.body.Uemail;
  if (req.body.Unmilitary == 'on')
  { var Unmilitary = 1;
    var Umilitary = 0;
   }
  if (req.body.Umilitary == 'on')
  {  var Unmilitary = 0;
    var Umilitary = 1;
   }
  var Uapplication = req.body.Uapplication;
  var Uexperience = req.body.Uexperience;



  var sql = 'INSERT INTO apply (Uname, Uclass, Unumber, Uphone, Uemail, Umilitary, Unmilitary, Uapplication,Uexperience) VALUES(?,?,?,?,?,?,?,?,?)';
  conn.query(sql, [Uname, Uclass, Unumber, Uphone, Uemail, Umilitary, Unmilitary, Uapplication, Uexperience], function (error, results, fields) {
    if (error) {
      console.log(error);
      res.status(500).send('error!!');
    } else {
      res.send('<script type="text/javascript">alert("제출 완료!"); document.location.replace("/login");</script>');
    }
  });
});

// router.get('/admin', function (req, res) {
//   res.render('admin', { title: 'admin' });
// });

router.get('/admin', function(req,res){
  if(req.session.displayName==1){
    var applyInfo="SELECT * FROM apply";
    conn.query(applyInfo, function(err,rows,fields){
      if(err){
        console.log(err);
      } else {
        res.render('admin',{apply : rows});
      }
    });
  } else {
    res.send('<script>alert("권한 없음");</script>');
  }
});





/////////////////////////////////////////////////////////






router.get('/Inst_login', function (req, res) {
  if (req.session.displayName) {//로그인성공했을때
    res.redirect('/Inst_feed');
  } else {
    res.render('Instagram_login');
  }
});

router.get('/', function (req, res) {
  res.render('Instagram_register');
})

router.get('/Inst_profile', function (req, res) {
  if (req.session.displayName) {//로그인성공했을때
    res.render('Instagram_profile');
  } else {
    //로그인 실패했을때
    res.redirect('/Inst_login');
  }
})

router.get('/Inst_feed', function (req, res) {
  if (req.session.displayName) {//로그인성공했을때
    res.render('Instagram_feed');
  } else {
    //로그인 실패했을때
    res.redirect('/Inst_login');
  }
})


router.post('/Inst_login', function (req, res) {
  var user = {
    phoneoremail: 'openyearround@naver.com',
    password: 'qwerasd1@#'
  };

  var phoemail = req.body.phoneoremail;
  var pwd = req.body.password;
  if (phoemail === user.phoneoremail && pwd === user.password) {
    req.session.displayName = user.phoneoremail;
    res.redirect('/Inst_feed');
  }
  else {
    res.send("Try again");
  }
  // res.send(phoemail);
});

router.get('/logout', function (req, res) {
  // delete req.session.displayName;
  req.session.destroy();
  res.clearCookie('sid');
  res.redirect('/');
});

module.exports = router;


/* GET home page. */
// router.get('/', function(req, res) {
//   res.render('Instagram_register', { title: 'register' });
// });
// router.get('/Inst_profile', function(req, res) {
//   res.render('Instagram_profile', { title: 'profile' });
// });
// router.get('/Inst_feed', function(req, res) {
//     console.log(req.session)
//   res.render('Instagram_feed', { title: 'feed' });
// });
// router.get('/Inst_login', function(req, res) {
//   res.render('Instagram_login', { title: 'login' });
// });


// router.use(session({
//     secret:'1234qwerasf!@#$asd', //랜덤한값
//     resave: false, 
//     saveUninitialized: true
// }));